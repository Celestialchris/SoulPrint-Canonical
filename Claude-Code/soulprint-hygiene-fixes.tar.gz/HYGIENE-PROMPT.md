# SoulPrint Repo Hygiene — Claude Code Prompt

Objective: Clean the repo for public launch. Fix stale references, consolidate config files, remove dead artifacts, archive superseded docs.

Starting State:
- 4 requirements*.txt files (redundant — pyproject.toml already defines all dependency groups)
- pytest.ini at root (redundant — pyproject.toml has [tool.pytest.ini_options])
- SoulPrint.spec at root (build artifact, belongs in scripts/)
- .gitignore corrupted with UTF-16LE null bytes on last entry
- .flaskenv has deprecated FLASK_ENV=development
- .claude/rules/brand.md references stale Torchlit Vault system (wine/gold/Cormorant)
- src/app/static/app-mock.html is 48KB superseded mock (live app is built)
- docs/superpowers/ has Claude Code auto-generated planning artifacts (internal, not public)
- docs/product/dual-theme-spec.md already marked archived at line 1 but still in active docs/
- ROADMAP.md references gitignored LAUNCH-PLAYBOOK.md
- CONTRIBUTING.md has stale "no USB framing" rule (product identity IS USB now)
- CLAUDE.md references deleted app-mock.html and requirements-minimal.txt
- .github/workflows/tests.yml references requirements-minimal.txt
- scripts/build_windows.bat references requirements-minimal.txt and requirements-build.txt
- roadmap/RELEASE-v0.1.0.md references requirements-minimal.txt, has stale counts
- README.md has stale counts, stale design system name, references requirements-minimal.txt
- docs/getting-started.md could mention pip install -e ".[intelligence]"

Target State:
- One requirements.txt (flask + flask-sqlalchemy)
- No pytest.ini (merged into pyproject.toml)
- SoulPrint.spec at scripts/SoulPrint.spec
- Clean .gitignore with .mcp.json entry properly encoded
- .flaskenv with just FLASK_APP line
- .claude/rules/brand.md references USB Drive system
- No app-mock.html
- docs/superpowers moved to docs/archive/superpowers
- dual-theme-spec.md moved to docs/archive/
- All cross-references updated
- All test/file counts accurate (47 files, 492 methods)
- Every CI workflow references requirements.txt

Allowed Actions:
- Delete files listed below
- Move files listed below
- Overwrite files listed below with fixed content
- Edit pyproject.toml to merge pytest.ini settings

Forbidden Actions:
- Do NOT change any Python source code in src/
- Do NOT change any test files
- Do NOT change any HTML templates or CSS
- Do NOT change DECISIONS.md or CHANGELOG.md (historical accuracy)
- Do NOT touch docs/reference/history/ files (they describe past state accurately)

## Execution Steps

### Step 1: Fix .gitignore
Replace the last line (corrupted null bytes) — strip from first null byte, add `.mcp.json\n` properly.

### Step 2: Delete redundant config files
```
rm requirements-minimal.txt
rm requirements-intelligence.txt
rm requirements-build.txt
rm pytest.ini
```

### Step 3: Overwrite requirements.txt
Content: just `flask\nflask-sqlalchemy\n`

### Step 4: Update pyproject.toml
Add `testpaths = ["tests"]` and `addopts = "-q"` to `[tool.pytest.ini_options]`.

### Step 5: Fix .flaskenv
Remove `FLASK_ENV=development` line. Keep only `FLASK_APP=src.run:app`.

### Step 6: Move SoulPrint.spec
```
git mv SoulPrint.spec scripts/SoulPrint.spec
```

### Step 7: Delete app-mock.html
```
rm src/app/static/app-mock.html
```

### Step 8: Archive superseded docs
```
mkdir -p docs/archive/superpowers/plans docs/archive/superpowers/specs
git mv docs/superpowers/plans/* docs/archive/superpowers/plans/
git mv docs/superpowers/specs/* docs/archive/superpowers/specs/
rmdir docs/superpowers/plans docs/superpowers/specs docs/superpowers
git mv docs/product/dual-theme-spec.md docs/archive/dual-theme-spec.md
```

### Step 9: Update all cross-references
Files to overwrite with fixed content:

**README.md** — new version with accurate counts (47 files, 492 methods), requirements.txt reference, no Torchlit Vault, one screenshot

**CLAUDE.md** — line 102: app-mock → app.css + brand.md reference. Line 47: remove requirements-minimal.txt mention.

**ROADMAP.md** — remove `roadmap/LAUNCH-PLAYBOOK.md` from Detail References (file is gitignored).

**CONTRIBUTING.md** — remove stale "No portability/USB/capsule framing" rule. Update "Desktop packaging" out-of-bounds to acknowledge PyInstaller is shipped.

**.claude/rules/brand.md** — full rewrite from Torchlit Vault to USB Drive system.

**.github/workflows/tests.yml** — change `requirements-minimal.txt` to `requirements.txt`.

**scripts/build_windows.bat** — change `requirements-minimal.txt -r requirements-build.txt` to `requirements.txt`, change `pip install -e .` to `pip install -e ".[build,dev]"`, change `SoulPrint.spec` to `scripts\SoulPrint.spec`.

**roadmap/RELEASE-v0.1.0.md** — change `requirements-minimal.txt` to `requirements.txt`, update stats.

**docs/README.md** — remove dual-theme-spec from Product section, add to Archive section.

**docs/getting-started.md** — mention `pip install -e ".[intelligence]"` for LLM features.

### Step 10: Verify
```
python -m pytest tests/ -v
```
All tests must still pass. This change touches zero Python code.

Commit message:
```
repo hygiene: consolidate config, fix stale refs, archive superseded docs

- Consolidate 4 requirements files → 1 (pyproject.toml is canonical)
- Merge pytest.ini into pyproject.toml
- Fix corrupted .gitignore (null bytes)
- Remove deprecated FLASK_ENV from .flaskenv
- Move SoulPrint.spec to scripts/
- Delete superseded app-mock.html (48KB)
- Archive docs/superpowers/ and dual-theme-spec.md
- Update all cross-references to match current state
- Fix .claude/rules/brand.md (Torchlit Vault → USB Drive)
- Accurate counts: 47 test files, 492 methods
```
